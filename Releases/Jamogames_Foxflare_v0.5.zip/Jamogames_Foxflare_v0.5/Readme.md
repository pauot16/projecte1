**README**

Github Link:  
[https://github.com/pauot16/projecte1](https://github.com/pauot16/projecte1)  
[https://github.com/pauot16/projecte1/wiki](https://github.com/pauot16/projecte1/wiki)

YouTube video:  
[https://youtu.be/B4QeBC5YWeU](https://youtu.be/B4QeBC5YWeU)

Team members:

- Biel Cadenas, [https://github.com/Cadebene](https://github.com/Cadebene)  
- Pau Gallego, [https://github.com/pauot16](https://github.com/pauot16)  
- David García, [https://github.com/chamardo](https://github.com/chamardo)  
- Paula Trigo, [https://github.com/paula-trigo](https://github.com/paula-trigo)

Description:  
Mario starts a new adventure to defeat Bowser but now Mario can protect himself from the enemies

How to play:  
Move left → A  
Move right → D  
Jump → W

Features implemented:

- Mario can move left/right  
- Mario can jump  
- You can kill the enemy  
- Mario and the enemy have animations  
- You can not pass platforms(collisions)