**Readme**

*Github Link:*  
[https://github.com/pauot16/projecte1](https://github.com/pauot16/projecte1)  
[https://github.com/pauot16/projecte1/wiki](https://github.com/pauot16/projecte1/wiki)

*YouTube video:*  
[https://youtu.be/SC5IxXc17Eg](https://youtu.be/SC5IxXc17Eg)

*Team members:*

- Biel Cadenas, [https://github.com/Cadebene](https://github.com/Cadebene)  
- Pau Gallego, [https://github.com/pauot16](https://github.com/pauot16)  
- David García, [https://github.com/chamardo](https://github.com/chamardo)  
- Paula Trigo, [https://github.com/paula-trigo](https://github.com/paula-trigo)

*Description:*  
Super Mariano Bros is a horizontal 2D Platform game where you control the displacement of the character but with the inconvenience that once the camera scrolls right you won't be able to go back in the level. In Mariano's adventure you will have to complete the level facing enemies, obstacles, and hidden secrets. The gameplay is iconic, featuring power-ups like the Super Mushroom, Fire Flower, and Starman, which help Mariano defeat enemies and progress through the levels.  
With all that, Mariano starts an adventure to rescue princess Pichy, protecting himself from the enemies and killing them.  
Will you be able to pass the level?

*How to play:*

- Move left → A  
- Move right → D  
- Jump → W  
- Shield → F

*Features implemented:*

- Mariano can use a shield when it’s small  
- Bill bala enemy   
- Interactive map  
- Mushroom power-up   
- Fire plant power-up  
- Star power-up